// @operator/capture-overlay — a composable in-browser capture overlay.
//
// Lifted from sitelayer's already-dependency-injected capture stack and re-homed
// onto @operator/projectkit: a captured moment becomes a projectkit
// CaptureEnvelope + WorkRequest, shipped through the site's ProjectSignal. The
// overlay imports NOTHING site-specific or mesh — a site supplies a small
// SiteAdapter (event stream + project_key + consent + signal + uploader), and
// routing (kanban / linear / agent) is a projectkit sink config swap.

export * from './recorder'
export * from './session'
export * from './hotkeys'
export * from './site-adapter'
