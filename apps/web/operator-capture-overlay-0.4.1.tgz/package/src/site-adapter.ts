import type { CaptureEnvelope, ProjectSignal } from '@operator/projectkit'

/**
 * Declares which capture streams / artifact kinds / event classes a site
 * permits. The overlay treats this as opaque authority — it never widens it.
 * (A richer consent authority can stay per-site; this is the minimal shape the
 * overlay needs to gate what it records.)
 */
export interface CaptureConsentScope {
  streams?: string[]
  artifact_kinds?: string[]
  event_classes?: string[]
}

/** Unsubscribe handle returned by a site's event stream subscription. */
export type Unsubscribe = () => void

/**
 * Uploads one captured media blob (audio / video / rrweb) and returns a ref
 * that the overlay embeds in the CaptureEnvelope (screenshot_ref / artifacts).
 * The site owns the storage (sitelayer multipart, nhl ingress, etc.).
 */
export type ArtifactUploader = (
  blob: Blob,
  meta: { kind: string; sessionId: string; contentType: string },
) => Promise<{ ref: string }>

/**
 * The minimal interface a site implements so the capture overlay drops on.
 * Only `eventStream` is genuinely per-site-shaped (it taps the site's XState
 * machine / engine transition log); the rest is configured wiring. Routing
 * (kanban / linear / agent / mesh) is a swap of the sink INSIDE `signal`,
 * never a change to this contract or the overlay — the One-Line Boundary Test.
 */
export interface SiteAdapter {
  /** projectkit project key, e.g. 'sitelayer' | 'nhl' | 'chess' | 'winwar'. */
  projectKey: string
  /**
   * Subscribe to the site's transition/event stream so capture marks correlate
   * to real app state. Returns an unsubscribe. For an XState machine this wraps
   * `actor.subscribe`; for winwar's engine it wraps `TransitionLog.recent`.
   */
  eventStream(onEvent: (event: unknown) => void): Unsubscribe
  /** The configured projectkit emitter (sink + HMAC live server-side). */
  signal: ProjectSignal
  /** Upload a captured media blob; returns a ref for the CaptureEnvelope. */
  uploadArtifact: ArtifactUploader
  /** Declared capture consent for this site/session. */
  consent(): CaptureConsentScope
}

export type { CaptureEnvelope }
