/**
 * capture-overlay — LinearSink. An @operator/projectkit EventSink that routes a
 * captured WorkRequest to a Linear issue via GraphQL `issueCreate`.
 *
 * Opt-in by a sink config swap, never a contract change:
 *   sink = new FanoutSink([
 *     new HttpSink({ url: SIGNAL_SINK_URL }),
 *     new LinearSink({ apiKey: LINEAR_API_KEY, teamId: LINEAR_TEAM_ID }),
 *   ])
 *
 * Inert when apiKey is absent (returns ok:true, accepted:0 so the overlay keeps
 * working). Extracts the WorkRequest the contract stamps as a `*.work.requested`
 * event (domain 'workflow_event', outcome 'requested', payload.work_request) and
 * maps it to issueCreate. intent / route_path / source_event_ref ride in the
 * description (Linear labelIds require pre-existing label UUIDs we don't have, so
 * we do NOT pass labelIds — an invalid id would fail the whole mutation).
 */

import type { EventSink, ProjectEventEnvelope, SinkResult, WorkRequest } from '@operator/projectkit'

export interface LinearSinkOptions {
  /** Linear API key. If absent, the sink is inert. */
  apiKey?: string
  /** Linear team ID to create issues in. */
  teamId: string
  /** Sink name for diagnostics. Default 'linear'. */
  name?: string
  /** Fetch implementation for injection. Defaults to globalThis.fetch. */
  fetchImpl?: typeof fetch
  /** Abort timeout in ms. Default 8000. */
  timeoutMs?: number
}

interface LinearCreateIssueResponse {
  data?: { issueCreate?: { success?: boolean; issue?: { id?: string; url?: string } } }
  errors?: Array<{ message: string }>
}

function extractWorkRequest(envelope: ProjectEventEnvelope): WorkRequest | null {
  for (const event of envelope.events) {
    if (event.domain === 'workflow_event' && event.outcome === 'requested' && event.payload?.work_request) {
      return event.payload.work_request as WorkRequest
    }
  }
  return null
}

function buildDescription(req: WorkRequest): string {
  const parts: string[] = []
  if (req.summary) parts.push(req.summary)
  const footer: string[] = []
  if (req.intent) footer.push(`Intent: ${req.intent}`)
  if (req.route_path) footer.push(`Route: ${req.route_path}`)
  if (req.source_event_ref) footer.push(`Source: ${req.source_event_ref}`)
  if (footer.length > 0) parts.push('\n---\n' + footer.join('\n'))
  return parts.join('\n')
}

/** Linear: 0 none, 1 urgent, 2 high, 3 medium, 4 low. */
function mapPriority(priority?: string): number | undefined {
  switch (priority) {
    case 'urgent':
      return 1
    case 'high':
      return 2
    case 'normal':
      return 3
    case 'low':
      return 4
    default:
      return undefined
  }
}

/** Routes a WorkRequest to a Linear issue via GraphQL issueCreate. */
export class LinearSink implements EventSink {
  readonly name: string
  private readonly apiKey: string | undefined
  private readonly teamId: string
  private readonly fetchImpl: typeof fetch
  private readonly timeoutMs: number

  constructor(opts: LinearSinkOptions) {
    if (!opts.teamId) throw new Error('LinearSink requires teamId')
    this.apiKey = opts.apiKey
    this.teamId = opts.teamId
    this.name = opts.name ?? 'linear'
    this.timeoutMs = opts.timeoutMs ?? 8000
    const f = opts.fetchImpl ?? (globalThis.fetch as typeof fetch | undefined)
    if (!f) throw new Error('LinearSink: no fetch available; pass opts.fetchImpl')
    this.fetchImpl = f
  }

  async deliver(envelope: ProjectEventEnvelope): Promise<SinkResult> {
    if (!this.apiKey) return { ok: true, sink: this.name, accepted: 0 }
    const req = extractWorkRequest(envelope)
    if (!req) return { ok: true, sink: this.name, accepted: 0 }

    // GraphQL variables (parameterized — no string injection into the query).
    const mutation =
      'mutation IssueCreate($input: IssueCreateInput!) { issueCreate(input: $input) { success issue { id url } } }'
    const priority = mapPriority(req.priority)
    const input: Record<string, unknown> = {
      teamId: this.teamId,
      title: req.title,
      description: buildDescription(req),
    }
    if (priority !== undefined) input.priority = priority

    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), this.timeoutMs)
    try {
      const res = await this.fetchImpl('https://api.linear.app/graphql', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: this.apiKey },
        body: JSON.stringify({ query: mutation, variables: { input } }),
        signal: controller.signal,
      })
      if (!res.ok) return { ok: false, sink: this.name, accepted: 0 }
      const data = (await res.json()) as LinearCreateIssueResponse
      if (data.errors && data.errors.length > 0) return { ok: false, sink: this.name, accepted: 0 }
      if (data.data?.issueCreate?.success && data.data.issueCreate.issue?.id) {
        return { ok: true, sink: this.name, accepted: 1 }
      }
      return { ok: false, sink: this.name, accepted: 0 }
    } catch {
      return { ok: false, sink: this.name, accepted: 0 }
    } finally {
      clearTimeout(timer)
    }
  }
}
