import { useCallback, useRef, useState, type CSSProperties, type ReactElement } from 'react'
import {
  AudioCaptureRecorder,
  ScreenCaptureRecorder,
  isAudioCaptureSupported,
  isScreenCaptureSupported,
} from './recorder'
import type { SiteAdapter } from './site-adapter'

// The composable capture overlay. Drops onto any site that supplies a
// SiteAdapter: renders a floating launcher, lets you jot a note + optionally
// record audio/screen while walking the app, and on send emits a projectkit
// WorkRequest (with uploaded artifact refs) through the adapter's signal. The
// routing target (kanban / linear / agent) is the sink inside adapter.signal —
// this component never knows or cares which.

export interface CaptureOverlayProps {
  adapter: SiteAdapter
  /** Launcher label. Default "Capture". */
  label?: string
}

type Phase = 'idle' | 'open' | 'recording' | 'sending' | 'sent'

const Z = 2147483600
const box: CSSProperties = {
  position: 'fixed',
  bottom: 16,
  right: 16,
  zIndex: Z,
  fontFamily: 'system-ui, sans-serif',
  fontSize: 14,
}
const btn: CSSProperties = {
  cursor: 'pointer',
  border: 'none',
  borderRadius: 8,
  padding: '8px 12px',
  background: '#111',
  color: '#fff',
}

export function CaptureOverlay({ adapter, label = 'Capture' }: CaptureOverlayProps): ReactElement {
  const [phase, setPhase] = useState<Phase>('idle')
  const [note, setNote] = useState('')
  const [recScreen, setRecScreen] = useState(false)
  const audioRef = useRef<AudioCaptureRecorder | null>(null)
  const screenRef = useRef<ScreenCaptureRecorder | null>(null)

  const startRecording = useCallback(async () => {
    try {
      if (isAudioCaptureSupported()) {
        audioRef.current = new AudioCaptureRecorder({})
        await audioRef.current.start()
      }
      if (recScreen && isScreenCaptureSupported()) {
        screenRef.current = new ScreenCaptureRecorder({})
        await screenRef.current.start()
      }
      setPhase('recording')
    } catch {
      // permission denied / unsupported — stay open without recording
      audioRef.current = null
      screenRef.current = null
    }
  }, [recScreen])

  const send = useCallback(async () => {
    setPhase('sending')
    const sessionId = globalThis.crypto?.randomUUID?.() ?? `cap_${Date.now()}`
    const artifacts: Array<{ kind: string; ref: string }> = []
    for (const [kind, ref] of [
      ['audio', audioRef],
      ['screen', screenRef],
    ] as const) {
      const rec = ref.current
      if (!rec) continue
      try {
        const result = await rec.stop()
        const up = await adapter.uploadArtifact(result.blob, { kind, sessionId, contentType: result.mime_type })
        artifacts.push({ kind, ref: up.ref })
      } catch {
        // upload failed — keep the rest of the capture
      }
      ref.current = null
    }
    const trimmed = note.trim()
    const title = (trimmed.split('\n')[0] || 'Captured issue').slice(0, 120)
    const routePath = typeof location !== 'undefined' ? location.pathname : undefined
    try {
      await adapter.signal.requestWork({
        request_ref: sessionId,
        intent: 'capture-followup',
        title,
        source_event_ref: sessionId,
        ...(trimmed ? { summary: trimmed } : {}),
        ...(routePath ? { route_path: routePath } : {}),
        ...(artifacts.length ? { payload: { artifacts } } : {}),
      })
    } catch {
      // fire-and-forget; the overlay never blocks the app
    }
    setNote('')
    setRecScreen(false)
    setPhase('sent')
    setTimeout(() => setPhase('idle'), 2000)
  }, [adapter, note])

  if (phase === 'idle') {
    return (
      <div style={box}>
        <button type="button" style={btn} onClick={() => setPhase('open')}>
          {label}
        </button>
      </div>
    )
  }
  if (phase === 'sent') {
    return (
      <div style={box}>
        <div style={{ ...btn, background: '#0a7' }}>Sent ✓</div>
      </div>
    )
  }

  const recording = phase === 'recording'
  return (
    <div style={{ ...box, width: 300, background: '#fff', border: '1px solid #ddd', borderRadius: 10, padding: 12 }}>
      <textarea
        autoFocus
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="What's the bug / task? (recording optional)"
        rows={3}
        style={{ width: '100%', boxSizing: 'border-box', resize: 'vertical', marginBottom: 8 }}
      />
      <label style={{ display: 'block', marginBottom: 8, color: '#333' }}>
        <input type="checkbox" checked={recScreen} onChange={(e) => setRecScreen(e.target.checked)} /> include screen
      </label>
      <div style={{ display: 'flex', gap: 8 }}>
        {!recording ? (
          <button type="button" style={{ ...btn, background: '#c33' }} onClick={startRecording}>
            ● Record
          </button>
        ) : (
          <span style={{ alignSelf: 'center', color: '#c33' }}>● recording…</span>
        )}
        <button type="button" style={{ ...btn, background: '#0a7' }} onClick={send} disabled={phase === 'sending'}>
          {phase === 'sending' ? 'Sending…' : 'Send'}
        </button>
        <button
          type="button"
          style={{ ...btn, background: '#888' }}
          onClick={() => {
            audioRef.current = null
            screenRef.current = null
            setPhase('idle')
          }}
        >
          Cancel
        </button>
      </div>
    </div>
  )
}
